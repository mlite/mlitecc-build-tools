#include <stdio.h>
#include <tcl.h>
#include <tk.h>

main ()
{
    puts(TCL_VERSION);
}
