char *strsave (char *s);        /* returns a pointer to a fresh copy of s */
