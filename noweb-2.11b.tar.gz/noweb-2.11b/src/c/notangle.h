void emit_module_named (FILE *out, char *rootname, char *locformat);
void read_defs(FILE *in);              /* read module definitions */
