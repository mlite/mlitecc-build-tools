extern int is_keyword(char *line, char *keyword);
extern int is_begin(char *line, char *type);
extern int is_end(char *line, char *type);
extern int is_index(char *line, char *type);
