print_endline Sys.os_type
;;
