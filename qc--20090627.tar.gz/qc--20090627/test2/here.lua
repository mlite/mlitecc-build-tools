Ld.rtend = "../lib/libqc--.a ../lib/pcmap.ld"
Ld.options = "-I../include -g"
