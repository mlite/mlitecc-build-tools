int globals_placeholder;
