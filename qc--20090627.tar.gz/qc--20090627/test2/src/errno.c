#include <errno.h>
int geterrno(void) { return errno; }
