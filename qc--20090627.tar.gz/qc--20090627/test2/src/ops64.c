long long ladd(long long x, long long y) {
  return x + y;
}
