#include <stdio.h>

float doubleme(float a) {
 printf("value passed in was %f\n", a);
 return a*2.0;
}
